function validation(){
	var first = document.getElementById('firstName').value;
	var last = document.getElementById('lastName').value;
	var pass = document.getElementById('password').value;
	var rePass = document.getElementById('retypePassword').value;
	var email = document.getElementById('e-mail').value;
	var mobile = document.getElementById('phone').value;
	var code = document.getElementById('code').value;

	var letters = /^[A-Za-z]+$/;

	if (first == "") {
		document.getElementById('first').innerHTML = "First Name cannot be Blank";
		return false;
	}
	if ((first.length < 4) || (first.length > 20)){
		document.getElementById('first').innerHTML = "First Name length must be between 4 and 20";
		return false;
	}
	if (!first.match(letters)){
		document.getElementById('first').innerHTML = "Only Characters are allowed";
		return false;
	}


	if (last == "") {
		document.getElementById('last').innerHTML = "Last Name cannot be Blank";
		return false;
	}
	if ((last.length < 4) || (last.length > 20)){
		document.getElementById('last').innerHTML = "Last Name length must be between 4 and 20";
		return false;
	}
	if (!last.match(letters)){
		document.getElementById('last').innerHTML = "Only Characters are allowed";
		return false;
	}


	
	if (pass == "") {
		document.getElementById('pass').innerHTML = "Password cannot be Blank";
		return false;
	}
	if ((pass.length < 6) || (pass.length > 16)){
		document.getElementById('pass').innerHTML = "Password length must be between 6 and 16";
	}


	if (rePass == "") {
		document.getElementById('rePass').innerHTML = "Retype Password cannot be Blank";
		return false;
	}
	if (rePass != pass) {
		document.getElementById('rePass').innerHTML = "Passwords not matched";
		return false;
	}



	if (email == "") {
		document.getElementById('e-mail').innerHTML = "E-Mail cannot be Blank";
		return false;
	}
	if(email.indexOf('@') <= 0){
		document.getElementById('e-mail').innerHTML = "'@' Invalid Position";
		return false;
	}
	if((email.charAt(email.length-4) != '.') && (email.charAt(email.length-3) != '.')){
		document.getElementById('e-mail').innerHTML = "'.' Invalid Position";
		return false;
	}


	if (mobile == "") {
		document.getElementById('mobile').innerHTML = "Phone Number cannot be Blank";
		return false;
	}
	if(mobile.length != 10){
		document.getElementById('mobile').innerHTML = "Phone Number length must be 10";	
		return false;	
	}
	if(isNaN(mobile)){
		document.getElementById('mobile').innerHTML = "Digits Only";
		return false;
	}
	


	if (code == "") {
		document.getElementById('send-code').innerHTML = "Code cannot be Blank";
		return false;
	}
	if(code.length != 4){
		document.getElementById('send-code').innerHTML = "Code length must be 4";	
		return false;	
	}
	if(isNaN(code)){
		document.getElementById('send-code').innerHTML = "Digits Only";
		return false;
	}
}

function code(){
	alert("Code send successfully");
}