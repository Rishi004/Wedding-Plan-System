function viewAll() {
	getElementById("view-alll").location.href = "view-all.html";
}