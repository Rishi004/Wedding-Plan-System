function Contact(){
	var first = document.getElementById('firstname').value;
	var last = document.getElementById('lastname').value;
	var email = document.getElementById('email').value;
	var mobile = document.getElementById('phone').value;
	var message = document.getElementById('msg').value;

	var letters = /^[A-Za-z]+$/;

	if (first == "") {
		document.getElementById('first').innerHTML = "First Name cannot be Blank";
		return false;
	}
	if ((first.length < 4) || (first.length > 20)){
		document.getElementById('first').innerHTML = "First Name length must be between 4 and 20";
	}
	if (!first.match(letters)){
		document.getElementById('first').innerHTML = "Only Characters are allowed";
		return false;
	}


	if (last == "") {
		document.getElementById('last').innerHTML = "Last Name cannot be Blank";
		return false;
	}
	if ((last.length < 4) || (last.length > 20)){
		document.getElementById('last').innerHTML = "Last Name length must be between 4 and 20";
	}
	if (!last.match(letters)){
		document.getElementById('last').innerHTML = "Only Characters are allowed";
		return false;
	}

	if (email == "") {
		document.getElementById('e-mail').innerHTML = "E-Mail cannot be Blank";
		return false;
	}
	if(email.indexOf('@') <= 0){
		document.getElementById('e-mail').innerHTML = "'@' Invalid Position";
		return false;
	}
	if((email.charAt(email.length-4) != '.') && (email.charAt(email.length-3) != '.')){
		document.getElementById('e-mail').innerHTML = "'.' Invalid Position";
		return false;
	}


	if (mobile == "") {
		document.getElementById('mobile').innerHTML = "Phone Number cannot be Blank";
		return false;
	}
	if(mobile.length != 10){
		document.getElementById('mobile').innerHTML = "Phone Number length must be 10";	
		return false;	
	}
	if(isNaN(mobile)){
		document.getElementById('mobile').innerHTML = "Digits Only";
		return false;
	}

	if (message == "") {
		document.getElementById('message').innerHTML = "Don't you say anything???";
		return false;
	}
	if(message.length > 200){
		document.getElementById('message').innerHTML = "within 200 characters";
		return false;
	}
}