function payMent(){
	var yourN = document.getElementById('yourName').value;
	var fiance = document.getElementById('fianceName').value;
	var add = document.getElementById('address').value;
	var code = document.getElementById('code').value;
	var mobile = document.getElementById('phone').value;
	var email = document.getElementById('email').value;

	var letters = /^[A-Za-z]+$/;

	if (yourN == "") {
		document.getElementById('your').innerHTML = "Your Name cannot be Blank";
		return false;
	}
	if ((yourN.length < 4) || (yourN.length > 20)){
		document.getElementById('your').innerHTML = "Your Name length must be between 4 and 20";
		return false;
	}
	if (!yourN.match(letters)){
		document.getElementById('your').innerHTML = "Only Characters are allowed";
		return false;
	}


	if (fiance == "") {
		document.getElementById('fiance').innerHTML = "Fiance Name cannot be Blank";
		return false;
	}
	if ((fiance.length < 4) || (fiance.length > 20)){
		document.getElementById('fiance').innerHTML = "fiance Name length must be between 4 and 20";
		return false;
	}
	if (!fiance.match(letters)){
		document.getElementById('fiance').innerHTML = "Only Characters are allowed";
		return false;
	}
}

function Pay(){
	var name = document.getElementById('name').value;
	var number = document.getElementById('number').value;
	var exDate = document.getElementById('date').value;
	var cVV = document.getElementById('cvv').value;

	var letters = /^[A-Za-z]+$/;

	if (name == "") {
		document.getElementById('card-name').innerHTML = "Name cannot be Blank";
		return false;
	}
	if ((name.length < 4) || (name.length > 20)){
		document.getElementById('card-name').innerHTML = "Name length must be between 4 and 20";
		return false;
	}
	if (!name.match(letters)){
		document.getElementById('card-name').innerHTML = "Only Characters are allowed";
		return false;
	}

	if (number == "") {
		document.getElementById('card-number').innerHTML = "Card number cannot be Blank";
		return false;
	}
	if(number.length != 16){
		document.getElementById('card-number').innerHTML = "Need Valid Card Number"
		return false;
	}
	if(isNaN(nNumber)){
		document.getElementById('card-number').innerHTML = "Only Digits are allowed"
		return false;
	}

	if (exDate == "") {
		document.getElementById('expiry-date').innerHTML = "Expiry date cannot be Blank";
		return false;
	}
	if (exDate.length != 5){
		document.getElementById('expiry-date').innerHTML = "Need Valid Expiry Date";
		return false;
	}
	if(exDate.indexOf('/') <= 0){
		document.getElementById('expiry-date').innerHTML = "'/' Invalid Position";
		return false;
	}
	if((exDate.charAt(exDate.length-2) != '/')){
		document.getElementById('expiry-date').innerHTML = "'/' Invalid Position";
		return false;
	}


	if (cVV == "") {
		document.getElementById('c-v-v').innerHTML = "CVV cannot be Blank";
		return false;
	}
	if(cVV.length != 3){
		document.getElementById('c-v-v').innerHTML = "Enter Valid CVV";
		return false;
	}
	if(isNaN(cVV)){
		document.getElementById('c-v-v').innerHTML = "Only Digits are allowed";
		return false;
	}
}
