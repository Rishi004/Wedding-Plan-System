function forgotten(){
	var email = document.getElementById('email').value;
	var code = document.getElementById('code').value;
	var pass = document.getElementById('password').value;
	var rePass = document.getElementById('retypePassword').value;


	if (email == "") {
		document.getElementById('e-mail').innerHTML = "E-Mail cannot be Blank";
		return false;
	}
	if(email.indexOf('@') <= 0){
		document.getElementById('e-mail').innerHTML = "'@' Invalid Position";
		return false;
	}
	if((email.charAt(email.length-4) != '.') && (email.charAt(email.length-3) != '.')){
		document.getElementById('e-mail').innerHTML = "'.' Invalid Position";
		return false;
	}


	if (code == "") {
		document.getElementById('send-code').innerHTML = "Code cannot be Blank";
		return false;
	}
	if(code.length != 4){
		document.getElementById('send-code').innerHTML = "Code length must be 4";	
		return false;	
	}
	if(isNaN(code)){
		document.getElementById('send-code').innerHTML = "Digits Only";
		return false;
	}


	if (pass == "") {
		document.getElementById('pass').innerHTML = "Password cannot be Blank";
		return false;
	}
	if ((pass.length < 6) || (pass.length > 16)){
		document.getElementById('pass').innerHTML = "Password length must be between 6 and 16";
	}


	if (rePass == "") {
		document.getElementById('rePass').innerHTML = "Retype Password cannot be Blank";
		return false;
	}
	if (rePass != pass) {
		document.getElementById('rePass').innerHTML = "Passwords not matched";
		return false;
	}
}