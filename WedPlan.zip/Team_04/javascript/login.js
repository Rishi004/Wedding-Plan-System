function logIn(){
	var email = document.getElementById('email').value;

	if (email == "") {
		document.getElementById('e-mail').innerHTML = "E-Mail cannot be Blank";
		return false;
	}
	if(email.indexOf('@') <= 0){
		document.getElementById('e-mail').innerHTML = "'@' Invalid Position";
		return false;
	}
	if((email.charAt(email.length-4) != '.') && (email.charAt(email.length-3) != '.')){
		document.getElementById('e-mail').innerHTML = "'.' Invalid Position";
		return false;
	}
}