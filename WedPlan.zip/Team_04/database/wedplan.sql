-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2020 at 05:38 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wedplan`
--

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `cardholder` varchar(255) NOT NULL,
  `cardno` int(17) NOT NULL,
  `expiry` varchar(255) NOT NULL,
  `cvv` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`cardholder`, `cardno`, `expiry`, `cvv`) VALUES
('John', 2147483647, '12/31', 123);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` int(11) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`firstname`, `lastname`, `email`, `mobile`, `message`) VALUES
('John', 'Smith', 'john@gmail.com', 771111111, 'hey hey');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`firstname`, `lastname`, `password`, `email`, `mobile`) VALUES
('John', 'Smith', '1bbd886460827015e5d605ed44252251', 'john@gmail.com', 771111111),
('Kevin', 'Martin', 'bae5e3208a3c700e3db642b6631e95b9', 'kevin@gmail.com', 772222222),
('Ludo', 'Krish', 'd27d320c27c3033b7883347d8beca317', 'ludo@gmail.com', 773333333),
('Matt', 'Damon', 'b857eed5c9405c1f2b98048aae506792', 'matt@gmail.com', 774444444),
('Jason', 'Mason', 'f638f4354ff089323d1a5f78fd8f63ca', 'jason@gmail.com', 775555555);

-- --------------------------------------------------------

--
-- Table structure for table `weddetails`
--

CREATE TABLE `weddetails` (
  `name` varchar(255) NOT NULL,
  `fiance` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `postal` int(6) NOT NULL,
  `mobile` int(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `datee` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
