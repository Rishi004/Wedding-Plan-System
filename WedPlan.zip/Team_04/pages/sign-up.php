<?php include('register.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/sign-up.css">
		<script type="text/javascript" src="../javascript/sign-up.js"></script>
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="sign-up.php">Sign Up</a></li>
				</ul>
			</nav>
			<div class="signup">
				<h1>Sign Up Here</h1>
				<form action="#" method="post" onsubmit="return validation()">
					<?php include('errors.php') ?>
					<div class="validate">
						<input type="text" name="firstname" id="firstName" placeholder="First name" autocomplete="off">
						<span id="first" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					</div>
					<div class="validate">
						<input type="text" name="lastname" id="lastName" placeholder="Last name" autocomplete="off">
						<span id="last" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					</div>
					<div class="validate">	
						<input type="password" name="password" id="password" placeholder="Password" autocomplete="off">
						<span id="pass" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					</div>
					<div class="validate">	
						<input type="password" name="rePass" id="retypePassword" placeholder="Retype Password" autocomplete="off">
						<span id="rePass" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					</div>
					<div class="validate">
						<input type="email" name="email" id="e-mail" placeholder="eg: eric@email.com" autocomplete="off">
						<span id="e-mail" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					</div>
					<div class="validate">
						<input type="text" name="mobile" id="phone" placeholder="eg: 0771234567" autocomplete="off">
						<span id="mobile" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					</div>
					<input type="submit" name="code" value="Send Code" class="code" autocomplete="off">
					<div class="validate">
						<input type="text" name="code" id="code" placeholder="eg: 1234" autocomplete="off">
						<span id="send-code" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					</div>
					<input type="submit" name="sign" value="Sign Up" class="sign" autocomplete="off">
				</form>			
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="login.php">Login</a></li>
						<li><a href="sign-up.php">Sign Up</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>