<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/services.css">
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
				</ul>
			</nav>
			<div>
				<div class="package">
					<h1>Packages</h1>
					<table>
						<tr>
							<td>
								<img src="../images/platinum.png" class="img">
								<form action="services-read-more.php" target="_blank">
									<input type="submit" value="Read More">
								</form>
							</td>
							<td>
								<img src="../images/gold.png" class="img">
								<form action="services-read-more-2.php" target="_blank">
									<input type="submit" value="Read More">
								</form>
							</td>
						</tr>
						<tr>
							<td>
								<img src="../images/silver.png" class="img">
								<form action="services-read-more-3.php" target="_blank">
									<input type="submit" value="Read More">
								</form>
							</td>
							<td>
								<img src="../images/bronze.png" class="img">
								<form action="services-read-more-4.php" target="_blank">
									<input type="submit" value="Read More">
								</form>
							</td>
						</tr>
					</table>
				</div>
				<div class="offer">
					<h1>Offers</h1>
					<table>
						<tr>
							<td>
								<img src="../images/birthday.jpg" class="img">
								<form action="services-read-more-5.php" target="_blank">
									<input type="submit" value="Read More">
								</form>
							</td>
						</tr>
						<tr>
							<td>
								<img src="../images/honeymoon.jpg" class="img">
								<form action="services-read-more-6.php" target="_blank">
									<input type="submit" value="Read More">
								</form>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; 123-456-789</span>
						<span>&nbsp; IT123-456@my.sliit.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>