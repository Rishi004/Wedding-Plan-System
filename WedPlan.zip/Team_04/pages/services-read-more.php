<!DOCTYPE html>
<html>
	<head>
		<title>Services Read More</title>
		<link rel="stylesheet" type="text/css" href="../css/services-read-more.css">
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="abount-us.php">About Us</a></li>
				</ul>
			</nav>
			<div style="margin-top: 20px; margin-left: 15%; max-width: 1000px;">
				<div>
					<div style="float: left; max-width: 400px;"><img src="../images/bundle.jpg" width="400" height="200"></div>
					<div style="float: right; max-width: 600px;">
						<p>As the name of this plan consists of maximum luxurious package from our service system. The package  provides entire premium features  from our website. Those who like to manage their event unforgettable for years can go for this package without any delay.
						It's the process of making something where there was once nothing at all.
The package consists of 3 major types which are novice , moderate, ace.
Select the package using your budget allocation and wedding type.
Basically , these packages  are  created by the criteria of budget and services.
Novice </p>
					</div>
				</div>
				<div>
					<div style="float: left; max-width: 600px;">
						<p>Novice is with a basic budget allocation is all way to 50 lakh.
This package includes 6 hours of  photography session with 1 photographer.
Other than that, a private online gallery with digital files.</p>
					</div>
					<div style="float: right; max-width: 400px;"><img src="../images/bundle.jpg" width="400" height="200"></div>
				</div>
				<div style="max-width: 1000px;">
					<p>Moderate is with a intermediate budget is all the way to 75 lakh.
This package includes 10 hours of photography session with 2 photographers and assistant engagement session. In additional , 30p  large Album with reception signing book</p>
					<p>Ace is luxury and maxed budget which is all the way to 100 lakh.
This package consists 12 hours of photography with 2 photographers  and  assistant  Engagement  session. In additional , private online  gallery with digital files. And moreover, custom website + cards design and 30p large album with cover upgrades and reception signing book.</p>
				</div>
				<form action="payment.php" target="_blank">
					<input type="submit" value="Book Now" class="book-now"></td>
				</form>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="abount-us.php">About Us</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>