<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/forgot-password.css">
		<script type="text/javascript" src="../javascript/forgot-password.js"></script>
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="sign-up.php">Sign Up</a></li>
				</ul>
			</nav>
			<div class="forgot">
				<h1>Reset Password</h1><br>
				<p class="para">Please enter your email address in the field above, once completed, you will receive an email containing a confirmation code shortly. This confirmation code will be used for the final step in resetting your passwoed</p><br>
				<form action="#" onsubmit="return forgotten()">
					<input type="text" name="email" id="email" placeholder="E-mail...">
					<span id="e-mail" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					<input class="code" type="submit" value="Send Code">
					<input type="text" name="code" id="code" placeholder="Code...">
					<span id="send-code" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					<input type="password" name="pass" id="password" placeholder="Password...">
					<span id="pass" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					<input type="password" name="re-pass" id="retypePassword" placeholder="Retype Password...">
					<span id="rePass" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					<input class="change" type="submit" value="Change Password">
				</form>			
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="login.php">Login</a></li>
						<li><a href="sign-up.php">Sign Up</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>