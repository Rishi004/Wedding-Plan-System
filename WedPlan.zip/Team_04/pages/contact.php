<?php

session_start();

$firstname = "";
$lastname = "";
$email = "";
$mobile = "";
$message = "";

$errors = array();

$db = mysqli_connect('localhost', 'root', '', 'wedplan') or die("could not connect to database");

if(isset($_POST['contact'])){
	$firstname = mysqli_real_escape_string($db, $_POST['firstname']);
	$lastname = mysqli_real_escape_string($db, $_POST['lastname']);
	$email = mysqli_real_escape_string($db, $_POST['email']);
	$mobile = mysqli_real_escape_string($db, $_POST['mobile']);
	$message = mysqli_real_escape_string($db, $_POST['message']);


if (empty($firstname)) {
	array_push($errors, "First Name cannot be blank");
}

if (empty($lastname)) {
	array_push($errors, "Last Name cannot be blank");
}

if (empty($email)) {
	array_push($errors, "Email cannot be blank");
}

if (empty($mobile)) {
	array_push($errors, "Phone Number cannot be blank");
}

if (empty($message)) {
	array_push($errors, "Message cannot be blank");
}


if(count($errors) == 0){
	$query = "INSERT INTO contact (firstname, lastname, email, mobile, message) VALUES ('$firstname', '$lastname', '$email', '$mobile', '$message')";

	mysqli_query($db, $query);
	$_SESSION['firstname'] = $firstname;
	
	header('location: contact-success.php');
}

}



?>