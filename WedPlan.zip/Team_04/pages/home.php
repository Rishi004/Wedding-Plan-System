<!DOCTYPE html>
	<html>
	<head>
		<title>Home</title>
		<link rel="stylesheet" type="text/css" href="../css/home.css">
		<script type="text/javascript" src="../js/home.js"></script>
	</head>
	<body>
		<div>
			<div class="banner1">
				<img src="../images/img_slide_1.jpg">
				<div class="logo">
					<img src="../images/logo.png">
				</div>
				<div>
					<ul class="menu">
						<li><a href="home.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="my-profile.php">My Profile</a></li>
					</ul>
				</div>
				<div class="text-box text-box1">
					<h1>Team Work Makes Dream work</h1>
					<span></span>
					<p style="font-size: 20px;">"Nobody has ever measured, even poets, how much a heart can hold.”<br>
—Zelda Fitzgerald</p>
				</div>
			</div>
			<div class="banner2">
				<img src="../images/img_slide_2.jpg">
				<div class="logo">
					<img src="../images/logo.png">
				</div>
				<div>
					<ul class="menu">
						<li><a href="home.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="my-profile.php">My Profile</a></li>
					</ul>
				</div>
				<div class="text-box text-box2">
					<h1>Silence Is Not Enough</h1>
					<span></span>
					<p>Many students define paragraphs in terms of length: a paragraph is a group of at least five sentences, a paragraph is half a page long, etc. ... Ultimately, a paragraph is a sentence or group of sentences that support one main idea.</p>
				</div>
			</div>
			<div class="banner3">
				<img src="../images/img_slide_3.jpg">
				<div class="logo">
					<img src="../images/logo.png">
				</div>
				<div>
					<ul class="menu">
						<li><a href="home.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="my-profile.php">My Profile</a></li>
					</ul>
				</div>
				<div class="text-box text-box3">
					<h1>Never Look Back</h1>
					<span></span>
					<p>Many students define paragraphs in terms of length: a paragraph is a group of at least five sentences, a paragraph is half a page long, etc. ... Ultimately, a paragraph is a sentence or group of sentences that support one main idea.</p>
				</div>
			</div>
			<div class="banner4">
				<img src="../images/img_slide_4.jpg">
				<div class="logo">
					<img src="../images/logo.png">
				</div>
				<div>
					<ul class="menu">
						<li><a href="home.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="my-profile.php">My Profile</a></li>
					</ul>
				</div>
				<div class="text-box text-box4">
					<h1>Born To Code</h1>
					<span></span>
					<p>Many students define paragraphs in terms of length: a paragraph is a group of at least five sentences, a paragraph is half a page long, etc. ... Ultimately, a paragraph is a sentence or group of sentences that support one main idea.</p>
				</div>
			</div>
		</div>
		<div class="scroll_2">
			<div class="left">
				<p style="text-align: center; margin-top: 10%; letter-spacing: 2px;">Today’s wedding planners have one of the most powerful and helpful tools at their fingertips – the Internet. Our website is best so far and affordable for the optimum use of budget.
If you are planning your wedding, take advantage of these user friendly online wedding planning tools to quickly formulate a personal planning agenda and easily navigate through any wedding planning hiccups.so, using our wedding system can literally save you money and stress free.
Our handy tools take the guesswork out of registering. Plus, you and your guests will love free shipping and returns, smart exchanges, and our friendly team of Registry Advisors. 
				</p>
				<p style="text-align: center; margin-top: -5%; letter-spacing: 2px;">"Nobody has ever measured, even poets, how much a heart can hold.”
—Zelda Fitzgerald</p>
			</div>
			<div class="right">
				<div style="margin-top: 15%; letter-spacing: 3px; text-align: center;">
					<h1>Mission</h1>
					<p style="text-align: center;">Our purpose to make sure that wedding couples remain stress free until the final special day and have a unforgettable day.</p>
				</div>
				<div style="margin-top: -5%; letter-spacing: 3px; text-align: center;">
					<h1>Vission</h1>
					<p style="text-align: center;">"To provide a memorable wedding to our generation"</p>
				</div>
			</div>
		</div>
		<div style="display: absolute;">
			<div style="width: 25%;">
				<img src="../images/service_1.jpg" class="service-img-1">
			</div>
			<div style="width: 25%; float: left;">
				<p class="service-para">Today, limos are one of the most popular transportation options because they offer benefits that go far beyond simply looking fancy.</p>
			</div>
			<div style="width: 25%;">
				<img src="../images/service_2.jpg" class="service-img-2">
			</div>
			<div style="width: 25%; float: left;">
				<p class="service-para">We want you to look back on your special day with no regrets. Therefore we've created a quality photograph community to capture the special Moment.</p>
			</div>
			<div style="width: 25%;">
				<img src="../images/service_3.jpg" class="service-img-3">
			</div>
			<div style="width: 25%; float: left;">
				<p class="service-para">Our catering team provides  a wide variety of foods to create a memorable dining experience.  From the cocktail hour to the cake, our signature recipes will amaze and delight!</p>
			</div>
			<div style="width: 25%;">
				<img src="../images/service_4.jpg" class="service-img-4">
			</div>
			<div style="width: 25%; float: right;">
				<p class="service-para">Wedding invitations and stationery are more than a way to keep our relatives and guests informed. Whether classic, rustic, modern, or vintage, we got you covered.</p>
				<button class="view-all" onclick="location.href = 'view-all.php'">View All</button>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2>
					<ul>
						<li><a href="home.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="my-profile.php">My profile</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>