<?php include('contact.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/contact-us.css">
		<script type="text/javascript" src="../javascript/contact-us.js"></script>
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
				</ul>
			</nav>
			<div>
				<div class="contact-form">
					<h2 style="text-align: center;">Contact Us</h2><br><br>
					<form action="#" method="post" onsubmit="return Contact()">
						<?php include('errors.php') ?>
						<input type="text" name="firstname" id="firstname" placeholder="First Name...">
						<span id="first" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="text" name="lastname" id="lastname" placeholder="Last Name...">
						<span id="last" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="text" name="email" id="email" placeholder="E-Mail...">
						<span id="e-mail" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="text" name="mobile" id="phone" placeholder="Phone Number..."><br><br>
						<span id="mobile" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<textarea name="message" id="msg" placeholder="Your Message..." class="msg"></textarea>
						<span id="message" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="submit" value="Send" name="contact" class="send">
					</form>
				</div>
				<div class="map">
					<p style="border:solid black 1px; position:relative; border-radius: 0;">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15843.194049543878!2d79.96418971807171!3d6.914677420060358!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae256db1a6771c5%3A0x2c63e344ab9a7536!2sSri%20Lanka%20Institute%20of%20Information%20Technology!5e0!3m2!1sen!2slk!4v1597867989085!5m2!1sen!2slk" width="400" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0">
						</iframe>
					</p><br><br>
					<ul>
						<li>
							<a href="#">Address</a>
							<a href="#">+94-77-1234-567</a>
							<a href="#">cupid'sarrow@gmail.com</a>
							<a href="https://www.facebook.com/" target="_blank">Facebook</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupidssarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="abount-us.php">About Us</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>