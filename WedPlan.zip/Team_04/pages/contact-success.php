<?php include('contact.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/contact-success.css">
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
				</ul>
			</nav>
			<div style="margin-top: 15%; margin-left: 42%; max-width: 200px;">
				<h2 class="success">Hey <strong><?php echo $_SESSION['firstname']; ?></strong>,</h2>
				<h2 class="success">Your message</h2>
				<h2 class="success">sent</h2>	
				<h2 class="success">successfully</h2>	
			</div>
		</div>
		</div>
	</body>
</html>