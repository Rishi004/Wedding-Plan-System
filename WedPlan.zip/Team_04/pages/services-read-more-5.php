<!DOCTYPE html>
<html>
	<head>
		<title>Services Read More</title>
		<link rel="stylesheet" type="text/css" href="../css/services-read-more.css">
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="abount-us.php">About Us</a></li>
				</ul>
			</nav>
			<div style="margin-top: 20px; margin-left: 15%; max-width: 1000px;">
				<div>
					<div style="float: left; max-width: 400px;"><img src="../images/bundle.jpg" width="400" height="200"></div>
					<div style="float: right; max-width: 600px;">
						<p>This package is additional offer package with Love Night package. This package not only for couple but also for the baby. Along with this offer , we take over the entire birthday with our quality service. We will  sent an amazing birthday for the newbie and tasteful birthday cake.

All services under our terms and conditions.
(Promocode is mandatory to access this package)</p>
					</div>
				</div>
				<div>
					<div style="float: left; max-width: 600px;">
						<p>This package is additional offer package with Love Night package. This package not only for couple but also for the baby. Along with this offer , we take over the entire birthday with our quality service. We will  sent an amazing birthday for the newbie and tasteful birthday cake.

All services under our terms and conditions.
(Promocode is mandatory to access this package)</p>
					</div>
					<div style="float: right; max-width: 400px;"><img src="../images/bundle.jpg" width="400" height="200"></div>
				</div>
				<div style="max-width: 1000px;">
					<p>This package is additional offer package with Love Night package. This package not only for couple but also for the baby. Along with this offer , we take over the entire birthday with our quality service. We will  sent an amazing birthday for the newbie and tasteful birthday cake.

All services under our terms and conditions.
(Promocode is mandatory to access this package)</p>
					<p>This package is additional offer package with Love Night package. This package not only for couple but also for the baby. Along with this offer , we take over the entire birthday with our quality service. We will  sent an amazing birthday for the newbie and tasteful birthday cake.

All services under our terms and conditions.
(Promocode is mandatory to access this package)</p>
				</div>
				<form action="payment.php" target="_blank">
					<input type="submit" value="Book Now" class="book-now"></td>
				</form>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="abount-us.php">About Us</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>