<!DOCTYPE html>
<html>
	<head>
		<title>View All</title>
		<link rel="stylesheet" type="text/css" href="../css/view-all.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<div>
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="sign-up.php">Sign Up</a></li>
				</ul>
			</nav>
			<div class="container">
				<div class="box">
					<div class="img-box">
						<img src="../images/service_1.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Limousine</h2>
							<p>Today, limos are one of the most popular transportation options because they offer benefits that go far beyond simply looking fancy.</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="img-box">
						<img src="../images/service_2.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Photography & Video</h2>
							<p>We want you to look back on your special day with no regrets. Therefore we've created a quality photograph community to capture the special Moment.</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="img-box">
						<img src="../images/service_3.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Catering</h2>
							<p>Our catering team provides  a wide variety of foods to create a memorable dining experience.  From the cocktail hour to the cake, our signature recipes will amaze and delight!</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="img-box">
						<img src="../images/service_4.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Invitations & Stationary</h2>
							<p>Wedding invitations and stationery are more than a way to keep our relatives and guests informed. Whether classic, rustic, modern, or vintage, we got you covered.</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="img-box">
						<img src="../images/service_5.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Wedding songs & music</h2>
							<p>Our wedding songs  is sure to keep your spirits up. Wedding songs selected will always remind the bride groom and guests of the fun and special moments  they had at the wedding.</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="img-box">
						<img src="../images/service_6.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Flowers</h2>
							<p>Make a imaginary statement by adding anemones to efflorescent. Flowers add a personal touch with decorations that have meaning.</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="img-box">
						<img src="../images/service_7.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Dress & Attire</h2>
							<p>A wedding  dress or the dress worn by the bride during  a monogamy. The colors, style and conventional importance oof the dress can depend  on the religion and culture of the wedding participants.</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="img-box">
						<img src="../images/service_8.jpg">
					</div>
					<div class="txt">
						<div class="content">
							<h2>Jewellery</h2>
							<p>Now a day, brides have been express their influence in terms of style and design, and jewelers.
Jewels and accessories will add a elegant for the brides.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="login.php">Login</a></li>
						<li><a href="sign-up.php">Sign Up</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>