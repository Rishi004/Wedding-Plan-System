<?php

session_start();

$firstname = "";
$lastname = "";
$email = "";
$mobile = "";

$errors = array();

$db = mysqli_connect('localhost', 'root', '', 'wedplan') or die("could not connect to database");

if(isset($_POST['sign'])){
	$firstname = mysqli_real_escape_string($db, $_POST['firstname']);
	$lastname = mysqli_real_escape_string($db, $_POST['lastname']);
	$password = mysqli_real_escape_string($db, $_POST['password']);
	$repassword = mysqli_real_escape_string($db, $_POST['rePass']);
	$email = mysqli_real_escape_string($db, $_POST['email']);
	$mobile = mysqli_real_escape_string($db, $_POST['mobile']);


if (empty($firstname)) {
	array_push($errors, "First Name cannot be blank");
}

if (empty($lastname)) {
	array_push($errors, "Last Name cannot be blank");
}

if (empty($password)) {
	array_push($errors, "Password cannot be blank");
}
if(strlen($password) < 8){
	array_push($errors, "Password length must be greater than 8");
}
if($password != $repassword){
	array_push($errors, "Passwords did not match");
}

if (empty($email)) {
	array_push($errors, "Email cannot be blank");
}

if (empty($mobile)) {
	array_push($errors, "Phone Number cannot be blank");
}

$users_check_query = "SELECT * FROM users WHERE email = '$email' LIMIT 1";

$results = mysqli_query($db, $users_check_query);
$users = mysqli_fetch_assoc($results);

if($users){
	if($users['email'] === $email){array_push($errors, "Email already exists");}
}

if(count($errors) == 0){
	$password = md5($password);
	$query = "INSERT INTO users (firstname, lastname, password, email, mobile) VALUES ('$firstname', '$lastname', '$password', '$email', '$mobile')";

	mysqli_query($db, $query);
	$_SESSION['firstname'] = $firstname;
	$_SESSION['email'] = $email;
	
	header('location: home.php');
}

}




if(isset($_POST['logg'])){
	$email = mysqli_real_escape_string($db, $_POST['email']);
	$pass = mysqli_real_escape_string($db, $_POST['pass']);


if (empty($email)) {
	array_push($errors, "Email cannot be blank");
}
if (empty($pass)) {
	array_push($errors, "Password cannot be blank");
}

if(count($errors) == 0){
	$pass = md5($pass);
	$queryy = "SELECT * FROM users WHERE email='$email' AND password='$pass'";

	$result = mysqli_query($db, $queryy);
	if(mysqli_num_rows($result)){
		$_SESSION['firstname'] = $firstname;
		$_SESSION['email'] = $email;
		header('location: home.php');
	}else{
		array_push($errors, "Incorrect Email/Password compination");
		
	}

}

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION['username']);
	unset($_SESSION['email']);

	header('location: index.php');
}

?>