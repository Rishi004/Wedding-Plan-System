<?php include('register.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/login.css">
		<script type="text/javascript" src="../javascript/login.js"></script>
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="sign-up.php">Sign Up</a></li>
				</ul>
			</nav>
			<div class="login">
				<h1>Login Here</h1><br>
				<form action="#" method="post" onsubmit="return logIn()">
					<?php include('errors.php') ?>
					<input type="text" name="email" id="email" placeholder="E-mail...">
					<span id="e-mail" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					<input type="password" name="pass" placeholder="Password...">
					<span id="password" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
					<input class="log" name="logg" type="submit" value="Login"><br><br><br>
					<a href="forgot-password.php">Forgot Password?</a><br>
					<a href="sign-up.php">Don't have an Account?</a>
				</form>			
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
						<li><a href="login.php">Login</a></li>
						<li><a href="sign-up.php">Sign Up</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.html" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>