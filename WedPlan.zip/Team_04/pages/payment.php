<?php include('pay.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title>Payment</title>
		<link rel="stylesheet" type="text/css" href="../css/payment.css">
		<script type="text/javascript" src="../javascript/payment.js"></script>
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
				</ul>
			</nav>
			<div>
				<div class="personal">
					<h1>God For You</h1>
					<form action="#" method="post" onsubmit="return payMent()">
						<?php include('errors.php') ?>
						<input type="text" name="namee" id="yourName" placeholder="Your Name...">
						<span id="your" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="text" name="fiance" id="fianceName" placeholder="Fiance Name...">
						<span id="fiance" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="text" name="address" id="address" placeholder="Address...">
						<span id="add" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="text" name="postal" id="postal" placeholder="Postal Code..." >
						<span id="post" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<input type="text" name="mobile" id="phone" placeholder="Phone Number...">
						<span id="mobile" style="color: red; font-size: 12px; font-family: sans-serif;"> </span><br>
						<input type="text" name="email" id="email" placeholder="E-mail...">
						<span id="e-mail" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
						<label for="bundle">Bundle:</label><br>
						<input type="radio" name="bundle" value="bundle-1" required>
						<label for="bundle-1">Bundle 1</label><br>
						<input type="radio" name="bundle" value="bundle-2" required>
						<label for="bundle-2">Bundle 2</label><br>
						<input type="radio" name="bundle" value="bundle-3" required>
						<label for="bundle-3">Bundle 3</label><br><br>
						<input type="text" name="datee" placeholder="Wedding Date" required>
						<input class="pay" name="next" type="submit" value="Next">
					</form>			
				</div>
				<div style="float: right;">
					<div>
						<img src="../images/pay.jpg" width="350" height="200" class="img">
					</div>
					<div class="payment">
						<h1>Adding Payment</h1>
						<form action="#" method="post" onsubmit="return Pay()">
							<?php include('errors.php') ?>
							
							<input type="text" name="cardholder" id="name" placeholder="Card Holder Name...">
							<span id="card-name" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
							<input type="text" name="cardno" id="number" placeholder="Card Number..." >
							<span id="card-number" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
							<input type="text" name="expiry" id="date" placeholder="Expiry Date (MM/YY)">
							<span id="expiry-date" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
							<input type="text" name="cvv" id="cvv" placeholder="CVV">
							<span id="c-v-v" style="color: red; font-size: 12px; font-family: sans-serif;"> </span>
							<input class="pay" name="payyy" type="submit" value="Done">
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="about-us.php">About Us</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; let's wed.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>