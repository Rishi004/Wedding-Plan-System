<?php

session_start();

$cardholder = "";
$cardno = "";
$expiry = "";
$cvv = "";

$errors = array();

$db = mysqli_connect('localhost', 'root', '', 'wedplan') or die("could not connect to database");

if(isset($_POST['payyy'])){
	$cardholder = mysqli_real_escape_string($db, $_POST['name']);
	$cardno = mysqli_real_escape_string($db, $_POST['fiance']);
	$expiry = mysqli_real_escape_string($db, $_POST['address']);
	$cvv = mysqli_real_escape_string($db, $_POST['postal']);


if (empty($cardholder)) {
	array_push($errors, "Cardholder Name cannot be blank");
}

if (empty($cardno)) {
	array_push($errors, "Card Number cannot be blank");
}

if (empty($expiry)) {
	array_push($errors, "Expiry Date cannot be blank");
}

if (empty($cvv)) {
	array_push($errors, "CVV cannot be blank");
}



if(count($errors) == 0){
	$query = "INSERT INTO card (cardholder, cardno, expiry, cvv) VALUES ('$cardholder', '$cardno', '$expiry', '$cvv')";

	mysqli_query($db, $query);
	$_SESSION['cardholder'] = $cardholder;
	
	header('location: payment-success.php');
}

}


?>