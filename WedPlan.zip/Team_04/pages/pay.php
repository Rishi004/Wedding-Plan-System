<?php

session_start();

$namee = "";
$fiance = "";
$address = "";
$postal = "";
$mobile = "";
$email = "";
$datee = "";
$cardholder = "";
$cardno = "";
$expiry = "";
$cvv = "";

$errors = array();

$db = mysqli_connect('localhost', 'root', '', 'wedplan') or die("could not connect to database");

if(isset($_POST['next'])){
	$namee = mysqli_real_escape_string($db, $_POST['namee']);
	$fiance = mysqli_real_escape_string($db, $_POST['fiance']);
	$address = mysqli_real_escape_string($db, $_POST['address']);
	$postal = mysqli_real_escape_string($db, $_POST['postal']);
	$mobile = mysqli_real_escape_string($db, $_POST['mobile']);
	$email = mysqli_real_escape_string($db, $_POST['email']);
	$datee = mysqli_real_escape_string($db, $_POST['datee']);


if (empty($namee)) {
	array_push($errors, "Your Name cannot be blank");
}

if (empty($fiance)) {
	array_push($errors, "Fiance Name cannot be blank");
}

if (empty($address)) {
	array_push($errors, "Address cannot be blank");
}

if (empty($postal)) {
	array_push($errors, "Postal Code cannot be blank");
}

if (empty($mobile)) {
	array_push($errors, "Phone Number cannot be blank");
}

if (empty($email)) {
	array_push($errors, "Email cannot be blank");
}

if (empty($datee)) {
	array_push($errors, "Date must be entered");
}

$users_check_query = "SELECT * FROM weddetails WHERE datee = '$datee' LIMIT 1";

$results = mysqli_query($db, $users_check_query);
$weddetails = mysqli_fetch_assoc($results);

if($weddetails){
	if($weddetails['datee'] === $datee){array_push($errors, "Date already taken");}
}

if(count($errors) == 0){
	$query = "INSERT INTO weddetails (name, fiance, address, postal, mobile, email, datee) VALUES ('$namee', '$fiance', '$address', '$postal', '$mobile', '$email', '$datee')";

	mysqli_query($db, $query);
	$_SESSION['name'] = $namee;
	$_SESSION['success'] = "Add your card details now.";
	
	header('location: payment.php');
}

}




if(isset($_POST['payyy'])){
	$cardholder = mysqli_real_escape_string($db, $_POST['cardholder']);
	$cardno = mysqli_real_escape_string($db, $_POST['cardno']);
	$expiry = mysqli_real_escape_string($db, $_POST['expiry']);
	$cvv = mysqli_real_escape_string($db, $_POST['cvv']);


if (empty($cardholder)) {
	array_push($errors, "Cardholder Name cannot be blank");
}

if (empty($cardno)) {
	array_push($errors, "Card Number cannot be blank");
}

if (empty($expiry)) {
	array_push($errors, "Expiry Date cannot be blank");
}

if (empty($cvv)) {
	array_push($errors, "CVV cannot be blank");
}



if(count($errors) == 0){
	$queryy = "INSERT INTO card (cardholder, cardno, expiry, cvv) VALUES ('$cardholder', '$cardno', '$expiry', '$cvv')";

	mysqli_query($db, $queryy);
	$_SESSION['cardholder'] = $cardholder;
	
	header('location: payment-success.php');
}

}
?>

