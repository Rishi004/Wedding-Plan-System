<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../css/about-us.css">
	</head>
	<body>
		<div id="main">
			<nav>
				<img src="../images/logo.png" width="160" height="80">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
				</ul>
			</nav>
			<div>
				<div style="float: left; max-width: 500px; max-height: 500px; margin-top: 2%; margin-left: 10%;">
					<img src="../images/about-us.jpg" width="450" height="250">
				</div>
				<div style="float: right; max-width: 500px; margin-top: 2%; margin-right: 10%;">
					<p style="font-family: poppins; font-size: 20px; font-style: italic; font-weight: bold; text-align: center;"><b>Cupid's Arrow</b> is a global leading company in making unforgettable weddings over the years now. Every day, <b>Cupid's Arrow</b> aims to make every couples happier and more productive by transforming the way to live the peaceful life. For 25 years, <b>Cupid's Arrow</b> has worked to transform the recruiting wedding planning system. Today, the company leverages advanced features like intelligent planning , wedding services , event management and a vast array of services. And our wedding system has successfully made over 250+ marriages.</p>
				</div>
			</div>
			<div style="margin-left: 10%; margin-top: 25%;">
				<h1 style="font-family: poppins; margin-left: 40%;">Our Team</h1><br><br>
				<table>
					<tr>
						<td><img src="../images/person-1.jpg" class="person"></td>
						<td><img src="../images/person-2.jpg" class="person"></td>
						<td><img src="../images/person-3.jpg" class="person"></td>
						<td><img src="../images/person-4.jpg" class="person"></td>
					</tr>
					<tr>
						<td style="width: 330px;"><h3 style="margin-left: 17%; ">James Smith</h3><h4 style="margin-left: 22%; color: lightgrey; margin-top: 10px;">Founder</h4><p style="text-align: left; padding: 30px; margin-left: -10%; letter-spacing: 1px;">James smith ( September 22, 1990) ( October 5, 2011) was an Sri Lankan business investor. He was the chairman, chief executive officer of Cupid's Arrow. He was the  first one to proffer the concept of online planning system concept in sri Lanka.
He worked hard to build this service system and we should be thankful to him.</p></td>

						<td style="width: 330px;"><h3 style="margin-left: 17%; margin-top: -5%;">Ashley John</h3><h4 style="margin-left: 22%; color: lightgrey; margin-top: 10px;">Co-Founder</h4><p style="text-align: left; padding: 30px; margin-left: -10%; letter-spacing: 1px;">Ashley John ( July 23.1990) was an American content writer. He was the  co-founder of the Cupid's Arrow.She has the one who assist and guide our team in well mannered way. And  she also a post graduate in business graduate. She has an amazing organizing skill.</p></td>

						<td style="width: 330px;"><h3 style="margin-left: 17%; margin-top: -10%;">Eric Mathew</h3><h4 style="margin-left: 22%; color: lightgrey; margin-top: 10px;">Costume Designer</h4><p style="text-align: left; padding: 30px; margin-left: -10%; letter-spacing: 1px;">Eric Matthew  (February 24,1992 )  was an Sri Lankan famous  Architectural and Engineering manager. His works has a personal touch which other wedding designers's works not have.he is post graduate in costume designing.</p></td>

						<td style="width: 330px;"><h3 style="margin-left: 13%; margin-top: -15%;">Scarlett Johanson</h3><h4 style="margin-left: 22%; color: lightgrey; margin-top: 10px;">Event Organizer</h4><p style="text-align: left; padding: 30px; margin-left: -10%; letter-spacing: 1px;">Scarlet johanson  (June 21 , 1993) was an Canadian Event Organizer of Cupid's Arrow. She is the one who organizes every event provided by Cupid's Arrow.
And she has good leadership qualities.</p></td>
					</tr>
				</table>
			</div>
		</div>
		<div class="footer">
			<div class="footer-content">
				<div class="footer-section about">
					<h1><span>Cupid's</span>Arrow</h1><br><br>
					<p style="font-size: 17px; font-weight: bold; font-style: italic;">Make Weddings Easier<br>Make Weddings Easier<br>Make Weddings Easier</p><br><br>
					<div class="contact">
						<span>&nbsp; +94-77-7677-019</span>
						<span>&nbsp; www.cupid'sarrow.lk</span>
					</div>
				</div>
				<div class="footer-section links">
					<h2>Quick Links</h2><br><br>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="services.php">Services</a></li>
						<li><a href="contact-us.php">Contact Us</a></li>
						<li><a href="abount-us.php">About Us</a></li>
					</ul>
				</div>
				<div class="footer-section feedback">
					<h2>Feedback</h2><br><br>
					<form action="index.php" method="post">
						<input type="email" name="email" placeholder="Your Email..." class="text-input contact-input">
						<textarea name="message" placeholder="Your Message..." class="text-input contact-input"></textarea>
						<button type="submit" class="bttn bttn-big contact-bttn"><i class="fa fa-paper-plane"></i>Send</button>
					</form>
				</div>
			</div>
			<div class="footer-bottom">
				&copy; Cupid's Arrow.lk | Designed by Team-04
			</div>
		</div>
	</body>
</html>